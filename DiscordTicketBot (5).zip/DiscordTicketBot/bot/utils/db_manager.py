import logging
from typing import Optional, Any, List, Dict, Union
from models import Guild, Panel, Ticket, EditSession

# Configuração de logging
logger = logging.getLogger('db_manager')

def initialize_guild_config(guild_id: Union[str, int]) -> None:
    """Inicializa a configuração do servidor com valores padrão"""
    guild_id = str(guild_id)
    
    try:
        # Chama a função get da classe Guild que inicializa com valores padrão se necessário
        Guild.get(guild_id)
        logger.info(f"Inicializada configuração para o servidor {guild_id}")
    except Exception as e:
        logger.error(f"Erro ao inicializar configuração do servidor {guild_id}: {e}")

def get_next_ticket_number(guild_id: str) -> int:
    """Obtém o próximo número de ticket disponível para um servidor"""
    guild_id = str(guild_id)
    
    try:
        # Obtém a configuração do servidor
        guild_config = Guild.get(guild_id)
        
        # Obtém o próximo número de ticket
        next_number = guild_config['next_ticket_number']
        
        # Incrementa o contador
        guild_config['next_ticket_number'] += 1
        Guild.update(guild_id, {'next_ticket_number': guild_config['next_ticket_number']})
        
        return next_number
    except Exception as e:
        logger.error(f"Erro ao obter próximo número de ticket para o servidor {guild_id}: {e}")
        return 1

def get_config(guild_id: str) -> dict:
    """Obtém a configuração do servidor"""
    guild_id = str(guild_id)
    
    try:
        # Obtém a configuração do servidor
        guild_config = Guild.get(guild_id)
        
        # Cria um dicionário com as configurações básicas (excluindo panels e tickets)
        config = {
            'next_ticket_number': guild_config['next_ticket_number'],
            'show_add_user_button': guild_config['show_add_user_button'],
            'show_remove_user_button': guild_config['show_remove_user_button'],
            'max_tickets_per_user': guild_config['max_tickets_per_user'],
            'can_members_close': guild_config['can_members_close'],
            'inactivity_time': guild_config['inactivity_time'],
            'auto_archive_tickets': guild_config['auto_archive_tickets'],
            'require_close_reason': guild_config['require_close_reason'],
            'notify_on_open': guild_config['notify_on_open'],
            'ticket_format': guild_config['ticket_format']
        }
        
        return config
    except Exception as e:
        logger.error(f"Erro ao obter configuração do servidor {guild_id}: {e}")
        
        # Retorna configuração padrão em caso de erro
        return Guild.get_default_config()

def update_config(guild_id: str, key: str, value: Any) -> bool:
    """Atualiza uma configuração específica do servidor"""
    guild_id = str(guild_id)
    
    # Lista de atributos permitidos para atualização
    allowed_attrs = [
        'show_add_user_button', 'show_remove_user_button', 
        'max_tickets_per_user', 'can_members_close', 
        'inactivity_time', 'auto_archive_tickets', 
        'require_close_reason', 'notify_on_open', 
        'ticket_format'
    ]
    
    if key not in allowed_attrs:
        logger.warning(f"Tentativa de atualizar atributo não permitido: {key}")
        return False
    
    try:
        # Atualiza o atributo
        update_data = {key: value}
        result = Guild.update(guild_id, update_data)
        
        if result:
            logger.info(f"Configuração {key} atualizada para: {value} (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao atualizar configuração {key} do servidor {guild_id}: {e}")
        return False

def get_panel_data(guild_id: str, panel_id: str) -> Optional[dict]:
    """Obtém os dados de um painel específico"""
    guild_id = str(guild_id)
    
    try:
        panel_data = Panel.get(guild_id, panel_id)
        return panel_data
    except Exception as e:
        logger.error(f"Erro ao obter painel {panel_id} do servidor {guild_id}: {e}")
        return None

def get_all_panels(guild_id: str) -> dict:
    """Obtém todos os painéis de um servidor"""
    guild_id = str(guild_id)
    
    try:
        panels_dict = Panel.get_all(guild_id)
        return panels_dict
    except Exception as e:
        logger.error(f"Erro ao obter painéis do servidor {guild_id}: {e}")
        return {}

def update_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Atualiza os dados de um painel específico"""
    guild_id = str(guild_id)
    
    try:
        result = Panel.update(guild_id, panel_id, panel_data)
        
        if result:
            logger.info(f"Painel {panel_id} atualizado (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao atualizar painel {panel_id} do servidor {guild_id}: {e}")
        return False

def create_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Cria um novo painel"""
    guild_id = str(guild_id)
    
    try:
        # Verifica se o painel já existe
        existing_panel = Panel.get(guild_id, panel_id)
        
        if existing_panel:
            return update_panel_data(guild_id, panel_id, panel_data)
        
        # Cria um novo painel
        result = Panel.create(guild_id, panel_id, panel_data)
        
        if result:
            logger.info(f"Painel {panel_id} criado (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao criar painel {panel_id} no servidor {guild_id}: {e}")
        return False

def delete_panel_data(guild_id: str, panel_id: str) -> bool:
    """Exclui um painel"""
    guild_id = str(guild_id)
    
    try:
        result = Panel.delete(guild_id, panel_id)
        
        if result:
            logger.info(f"Painel {panel_id} excluído (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao excluir painel {panel_id} do servidor {guild_id}: {e}")
        return False

def get_ticket_data(guild_id: str, channel_id: str) -> Optional[dict]:
    """Obtém os dados de um ticket específico"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    
    try:
        ticket_data = Ticket.get(guild_id, channel_id)
        return ticket_data
    except Exception as e:
        logger.error(f"Erro ao obter ticket {channel_id} do servidor {guild_id}: {e}")
        return None

def count_user_tickets(guild_id: str, user_id: str, guild=None) -> int:
    """Conta os tickets abertos por um usuário
    
    Args:
        guild_id (str): ID do servidor
        user_id (str): ID do usuário
        guild (discord.Guild, optional): Instância do servidor para verificar existência do canal. Defaults to None.
    
    Returns:
        int: Número de tickets abertos
    """
    guild_id = str(guild_id)
    user_id = str(user_id)
    
    try:
        # Se o guild foi fornecido, verifica se os canais ainda existem
        if guild:
            verify_ticket_channels(guild)
        
        # Usa a função de contagem da classe Ticket
        count = Ticket.count_user_tickets(guild_id, user_id)
        return count
    except Exception as e:
        logger.error(f"Erro ao contar tickets do usuário {user_id} no servidor {guild_id}: {e}")
        return 0

def update_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Atualiza os dados de um ticket específico"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    
    try:
        result = Ticket.update(guild_id, channel_id, ticket_data)
        
        if result:
            logger.info(f"Ticket {channel_id} atualizado (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao atualizar ticket {channel_id} do servidor {guild_id}: {e}")
        return False

def create_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Cria um novo ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    
    try:
        # Verifica se o ticket já existe
        existing_ticket = Ticket.get(guild_id, channel_id)
        
        if existing_ticket:
            return update_ticket_data(guild_id, channel_id, ticket_data)
        
        # Cria um novo ticket
        result = Ticket.create(guild_id, channel_id, ticket_data)
        
        if result:
            logger.info(f"Ticket {channel_id} criado (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao criar ticket {channel_id} no servidor {guild_id}: {e}")
        return False

def delete_ticket_data(guild_id: str, channel_id: str) -> bool:
    """Exclui um ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    
    try:
        result = Ticket.delete(guild_id, channel_id)
        
        if result:
            logger.info(f"Ticket {channel_id} excluído (Servidor: {guild_id})")
        
        return result
    except Exception as e:
        logger.error(f"Erro ao excluir ticket {channel_id} do servidor {guild_id}: {e}")
        return False

def get_edit_session(user_id: str, guild_id: str) -> Optional[dict]:
    """Obtém a sessão de edição de painel para um usuário"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    
    try:
        session_data = EditSession.get(user_id, guild_id)
        return session_data
    except Exception as e:
        logger.error(f"Erro ao obter sessão de edição do usuário {user_id} no servidor {guild_id}: {e}")
        return None

def initialize_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Inicializa ou atualiza a sessão de edição de painel para um usuário"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    
    try:
        result = EditSession.create(user_id, guild_id, panel_data)
        
        if result:
            logger.info(f"Sessão de edição inicializada para o usuário {user_id} no servidor {guild_id}")
    except Exception as e:
        logger.error(f"Erro ao inicializar sessão de edição para o usuário {user_id} no servidor {guild_id}: {e}")

def update_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Atualiza a sessão de edição de painel para um usuário"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    
    try:
        result = EditSession.update(user_id, guild_id, panel_data)
        
        if result:
            logger.info(f"Sessão de edição atualizada para o usuário {user_id} no servidor {guild_id}")
    except Exception as e:
        logger.error(f"Erro ao atualizar sessão de edição para o usuário {user_id} no servidor {guild_id}: {e}")

def clean_edit_session(user_id: str, guild_id: str) -> None:
    """Limpa a sessão de edição de painel para um usuário"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    
    try:
        result = EditSession.delete(user_id, guild_id)
        
        if result:
            logger.info(f"Sessão de edição limpa para o usuário {user_id} no servidor {guild_id}")
    except Exception as e:
        logger.error(f"Erro ao limpar sessão de edição para o usuário {user_id} no servidor {guild_id}: {e}")

def verify_ticket_channels(guild) -> int:
    """Verifica se os canais de ticket ainda existem e remove os que não existem mais"""
    guild_id = str(guild.id)
    removed_count = 0
    
    try:
        # Obtém todos os tickets do servidor
        guild_config = Guild.get(guild_id)
        
        if 'tickets' not in guild_config:
            return 0
        
        tickets = guild_config['tickets']
        tickets_to_remove = []
        
        # Verifica se cada canal de ticket ainda existe
        for channel_id, ticket_data in tickets.items():
            try:
                # Tenta obter o canal pelo ID
                channel = guild.get_channel(int(channel_id))
                
                # Se o canal não existir, marca para remoção
                if not channel:
                    tickets_to_remove.append(channel_id)
            except:
                # Se houver erro ao obter o canal, marca para remoção
                tickets_to_remove.append(channel_id)
        
        # Remove os tickets com canais inexistentes
        for channel_id in tickets_to_remove:
            Ticket.delete(guild_id, channel_id)
            removed_count += 1
        
        if removed_count > 0:
            logger.info(f"Removidos {removed_count} tickets com canais inexistentes (Servidor: {guild_id})")
        
        return removed_count
    except Exception as e:
        logger.error(f"Erro ao verificar canais de ticket no servidor {guild_id}: {e}")
        return 0