"""
Este arquivo contém funções para compatibilidade com o código existente, redirecionando
chamadas para o sistema de banco de dados PostgreSQL.
"""

import logging
from typing import Optional, Any, List, Dict, Union
from utils import db_manager

# Configuração de logging
logger = logging.getLogger('db_helper')

# Funções de compatibilidade com o config_manager
def _load_json(file_path: str) -> dict:
    """Função para compatibilidade. Retorna um dicionário vazio."""
    return {}

def _save_json(file_path: str, data: dict) -> bool:
    """Função para compatibilidade. Retorna sempre True."""
    return True

def initialize_guild_config(guild_id: Union[str, int]) -> None:
    """Inicializa a configuração do servidor com valores padrão"""
    db_manager.initialize_guild_config(guild_id)

def get_next_ticket_number(guild_id: str) -> int:
    """Obtém o próximo número de ticket disponível para um servidor"""
    return db_manager.get_next_ticket_number(guild_id)

def get_config(guild_id: str) -> dict:
    """Obtém a configuração do servidor"""
    return db_manager.get_config(guild_id)

def update_config(guild_id: str, key: str, value: Any) -> bool:
    """Atualiza uma configuração específica do servidor"""
    return db_manager.update_config(guild_id, key, value)

def get_panel_data(guild_id: str, panel_id: str) -> Optional[dict]:
    """Obtém os dados de um painel específico"""
    return db_manager.get_panel_data(guild_id, panel_id)

def get_all_panels(guild_id: str) -> dict:
    """Obtém todos os painéis de um servidor"""
    return db_manager.get_all_panels(guild_id)

def update_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Atualiza os dados de um painel específico"""
    return db_manager.update_panel_data(guild_id, panel_id, panel_data)

def create_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Cria um novo painel"""
    return db_manager.create_panel_data(guild_id, panel_id, panel_data)

def delete_panel_data(guild_id: str, panel_id: str) -> bool:
    """Exclui um painel"""
    return db_manager.delete_panel_data(guild_id, panel_id)

def get_ticket_data(guild_id: str, channel_id: str) -> Optional[dict]:
    """Obtém os dados de um ticket específico"""
    return db_manager.get_ticket_data(guild_id, channel_id)

def count_user_tickets(guild_id: str, user_id: str, guild=None) -> int:
    """Conta os tickets abertos por um usuário"""
    return db_manager.count_user_tickets(guild_id, user_id, guild)

def update_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Atualiza os dados de um ticket específico"""
    return db_manager.update_ticket_data(guild_id, channel_id, ticket_data)

def create_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Cria um novo ticket"""
    return db_manager.create_ticket_data(guild_id, channel_id, ticket_data)

def delete_ticket_data(guild_id: str, channel_id: str) -> bool:
    """Exclui um ticket"""
    return db_manager.delete_ticket_data(guild_id, channel_id)

def get_edit_session(user_id: str, guild_id: str) -> Optional[dict]:
    """Obtém a sessão de edição de painel para um usuário"""
    return db_manager.get_edit_session(user_id, guild_id)

def initialize_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Inicializa ou atualiza a sessão de edição para um usuário"""
    db_manager.initialize_edit_session(user_id, guild_id, panel_data)

def update_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Atualiza a sessão de edição para um usuário"""
    db_manager.update_edit_session(user_id, guild_id, panel_data)

def clean_edit_session(user_id: str, guild_id: str) -> None:
    """Limpa a sessão de edição para um usuário"""
    db_manager.clean_edit_session(user_id, guild_id)