import os
import logging

# Configure logging
logger = logging.getLogger('emoji_config')

class Emoji:
    # Panel configuration
    ADD = "➕"
    EDIT = "✏️"
    DELETE = "🗑️"
    SETTINGS = "⚙️"
    
    # Panel appearance
    COLOR = "🎨"
    TEXT = "📝"
    DESCRIPTION = "📄"
    ROLE = "👥"
    CATEGORY = "📁"
    APPEARANCE = "🎭"
    
    # Button styles
    STYLE = "🎨"
    EMOJI = "😀"
    
    # Ticket actions
    LOCK = "🔒"
    WAVE = "👋"
    BELL = "🔔"
    ARCHIVE = "📂"
    USERS = "👥"
    TRANSCRIPT = "📝"
    
    # Priority levels
    PRIORITY_NONE = "⚪"
    PRIORITY_LOW = "🟢"
    PRIORITY_MEDIUM = "🟡"
    PRIORITY_HIGH = "🔺"
    
    # Navigation
    BACK = "⬅️"
    SAVE = "💾"
    CANCEL = "❌"
    
    # Dropdown
    DROPDOWN = "📋"
    
    # Visibility
    VISIBLE = "👁️"
    
    # Settings
    TICKETS_PER_USER = "🎟️"
    MEMBER_CLOSE = "🚪"
    INACTIVITY = "⏱️"
    AUTO_ARCHIVE = "📂"
    REQUIRE_REASON = "📝"
    NOTIFY_ON_OPEN = "🔔"
    TICKET_FORMAT = "🏷️"
    
    @staticmethod
    def load_from_file():
        """Carrega os emojis do arquivo emojis.txt"""
        try:
            if not os.path.exists('emojis.txt'):
                logger.warning("Arquivo emojis.txt não encontrado. Usando emojis padrão.")
                return
                
            with open('emojis.txt', 'r', encoding='utf-8') as file:
                lines = file.readlines()
                
            emoji_dict = {}
            current_section = None
            
            for line in lines:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                    
                parts = line.split('=')
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    # Verificar se o atributo existe na classe
                    if hasattr(Emoji, key):
                        # Atualizar o valor do atributo
                        setattr(Emoji, key, value)
                        emoji_dict[key] = value
                        logger.info(f"Emoji {key} atualizado para: {value}")
                        print(f"Emoji {key} atualizado para: {value}")
            
            logger.info(f"Carregados {len(emoji_dict)} emojis personalizados de emojis.txt")
            print(f"Carregados {len(emoji_dict)} emojis personalizados de emojis.txt")
            
        except Exception as e:
            logger.error(f"Erro ao carregar emojis do arquivo: {e}")
            print(f"Erro ao carregar emojis do arquivo: {e}")

# Carregar emojis do arquivo ao importar este módulo
try:
    Emoji.load_from_file()
except Exception as e:
    logger.error(f"Falha ao carregar emojis: {e}")
    print(f"Falha ao carregar emojis: {e}")
