import os
import json
from typing import Union, Optional, Any, Dict

# Ensure data directories exist
os.makedirs('data', exist_ok=True)
os.makedirs('data/guilds', exist_ok=True)
os.makedirs('data/panels', exist_ok=True)
os.makedirs('data/tickets', exist_ok=True)
os.makedirs('data/edit_sessions', exist_ok=True)

def _load_json(file_path: str) -> dict:
    """Load JSON data from file, create if not exists"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # Return empty dict and create directory if needed
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        return {}

def _save_json(file_path: str, data: dict) -> bool:
    """Save JSON data to file"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving file {file_path}: {e}")
        return False

def initialize_guild_config(guild_id: Union[str, int]) -> None:
    """Initialize guild configuration with default values"""
    guild_id = str(guild_id)
    guild_file = f'data/guilds/{guild_id}.json'
    
    # Only initialize if not already exists
    if not os.path.exists(guild_file):
        default_config = {
            "ticket_format": "ticket-{number}",
            "max_tickets_per_user": 1,
            "inactivity_time": 0,  # 0 = disabled
            "next_ticket_number": 1,
            "show_add_user_button": True,
            "show_remove_user_button": True,
            "can_members_close": True,
            "auto_archive_tickets": False,
            "require_close_reason": True,
            "notify_on_open": False
        }
        _save_json(guild_file, default_config)

def get_next_ticket_number(guild_id: str) -> int:
    """Get the next available ticket number for a guild"""
    guild_id = str(guild_id)
    guild_file = f'data/guilds/{guild_id}.json'
    
    # Load guild config
    guild_config = _load_json(guild_file)
    
    # Get and increment ticket number
    ticket_number = guild_config.get('next_ticket_number', 1)
    guild_config['next_ticket_number'] = ticket_number + 1
    
    # Save updated config
    _save_json(guild_file, guild_config)
    
    return ticket_number

def get_config(guild_id: str) -> dict:
    """Get guild configuration"""
    guild_id = str(guild_id)
    guild_file = f'data/guilds/{guild_id}.json'
    
    # Initialize if not exists
    if not os.path.exists(guild_file):
        initialize_guild_config(guild_id)
    
    return _load_json(guild_file)

def update_config(guild_id: str, key: str, value: Any) -> bool:
    """Update a specific configuration setting"""
    guild_id = str(guild_id)
    guild_file = f'data/guilds/{guild_id}.json'
    
    # Load guild config
    guild_config = _load_json(guild_file)
    
    # Update setting
    guild_config[key] = value
    
    # Save updated config
    return _save_json(guild_file, guild_config)

def get_panel_data(guild_id: str, panel_id: str) -> Optional[dict]:
    """Get data for a specific panel"""
    guild_id = str(guild_id)
    panel_id = str(panel_id)
    panel_file = f'data/panels/{guild_id}/{panel_id}.json'
    
    if os.path.exists(panel_file):
        return _load_json(panel_file)
    return None

def get_all_panels(guild_id: str) -> dict:
    """Get all panels for a guild"""
    guild_id = str(guild_id)
    panels_dir = f'data/panels/{guild_id}'
    
    panels = {}
    if os.path.exists(panels_dir):
        for filename in os.listdir(panels_dir):
            if filename.endswith('.json'):
                panel_id = filename.split('.')[0]
                panel_file = os.path.join(panels_dir, filename)
                panel_data = _load_json(panel_file)
                panels[panel_id] = panel_data
    
    return panels

def update_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Update data for a specific panel"""
    guild_id = str(guild_id)
    panel_id = str(panel_id)
    panels_dir = f'data/panels/{guild_id}'
    os.makedirs(panels_dir, exist_ok=True)
    
    panel_file = f'{panels_dir}/{panel_id}.json'
    return _save_json(panel_file, panel_data)

def create_panel_data(guild_id: str, panel_id: str, panel_data: dict) -> bool:
    """Create a new panel"""
    guild_id = str(guild_id)
    panel_id = str(panel_id)
    panels_dir = f'data/panels/{guild_id}'
    os.makedirs(panels_dir, exist_ok=True)
    
    panel_file = f'{panels_dir}/{panel_id}.json'
    
    # Don't overwrite if exists
    if os.path.exists(panel_file):
        return False
    
    return _save_json(panel_file, panel_data)

def delete_panel_data(guild_id: str, panel_id: str) -> bool:
    """Delete a panel"""
    guild_id = str(guild_id)
    panel_id = str(panel_id)
    panel_file = f'data/panels/{guild_id}/{panel_id}.json'
    
    if os.path.exists(panel_file):
        try:
            os.remove(panel_file)
            return True
        except:
            return False
    return False

def get_ticket_data(guild_id: str, channel_id: str) -> Optional[dict]:
    """Get data for a specific ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    ticket_file = f'data/tickets/{guild_id}/{channel_id}.json'
    
    if os.path.exists(ticket_file):
        return _load_json(ticket_file)
    return None

def verify_ticket_channels(guild) -> int:
    """Verify if ticket channels still exist and remove those that don't
    
    Args:
        guild: Discord guild object
        
    Returns:
        int: Number of removed tickets
    """
    guild_id = str(guild.id)
    tickets_dir = f'data/tickets/{guild_id}'
    removed_count = 0
    
    if not os.path.exists(tickets_dir):
        return 0
    
    for filename in os.listdir(tickets_dir):
        if filename.endswith('.json'):
            channel_id = filename.split('.')[0]
            
            # Check if channel exists in guild
            channel = guild.get_channel(int(channel_id))
            if not channel:
                # Channel doesn't exist, remove ticket
                ticket_file = os.path.join(tickets_dir, filename)
                try:
                    os.remove(ticket_file)
                    removed_count += 1
                    print(f"Removed ticket for non-existent channel {channel_id} in guild {guild_id}")
                except:
                    print(f"Failed to remove ticket file {ticket_file}")
    
    return removed_count

def count_user_tickets(guild_id: str, user_id: str, guild=None) -> int:
    """Count open tickets for a user
    
    Args:
        guild_id (str): ID do servidor
        user_id (str): ID do usuário
        guild (discord.Guild, optional): Instância do servidor para verificar existência do canal. Defaults to None.
    
    Returns:
        int: Número de tickets abertos
    """
    guild_id = str(guild_id)
    user_id = str(user_id)
    tickets_dir = f'data/tickets/{guild_id}'
    count = 0
    
    if not os.path.exists(tickets_dir):
        return 0
    
    for filename in os.listdir(tickets_dir):
        if filename.endswith('.json'):
            ticket_file = os.path.join(tickets_dir, filename)
            try:
                ticket_data = _load_json(ticket_file)
                
                # Check if ticket is from the user and is open
                if (ticket_data.get('user_id') == user_id and 
                    not ticket_data.get('closed', False)):
                    
                    # If guild is provided, verify channel exists
                    if guild:
                        channel_id = filename.split('.')[0]
                        channel = guild.get_channel(int(channel_id))
                        if channel:
                            count += 1
                    else:
                        count += 1
            except:
                continue
    
    return count

def update_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Update data for a specific ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    tickets_dir = f'data/tickets/{guild_id}'
    os.makedirs(tickets_dir, exist_ok=True)
    
    ticket_file = f'{tickets_dir}/{channel_id}.json'
    return _save_json(ticket_file, ticket_data)

def create_ticket_data(guild_id: str, channel_id: str, ticket_data: dict) -> bool:
    """Create a new ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    tickets_dir = f'data/tickets/{guild_id}'
    os.makedirs(tickets_dir, exist_ok=True)
    
    ticket_file = f'{tickets_dir}/{channel_id}.json'
    return _save_json(ticket_file, ticket_data)

def delete_ticket_data(guild_id: str, channel_id: str) -> bool:
    """Delete a ticket"""
    guild_id = str(guild_id)
    channel_id = str(channel_id)
    ticket_file = f'data/tickets/{guild_id}/{channel_id}.json'
    
    if os.path.exists(ticket_file):
        try:
            os.remove(ticket_file)
            return True
        except:
            return False
    return False

def get_edit_session(user_id: str, guild_id: str) -> Optional[dict]:
    """Get panel edit session for a user"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    session_file = f'data/edit_sessions/{user_id}_{guild_id}.json'
    
    if os.path.exists(session_file):
        return _load_json(session_file)
    return None

def initialize_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Initialize or update edit session for a user"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    session_file = f'data/edit_sessions/{user_id}_{guild_id}.json'
    _save_json(session_file, panel_data)

def update_edit_session(user_id: str, guild_id: str, panel_data: dict) -> None:
    """Update edit session for a user"""
    initialize_edit_session(user_id, guild_id, panel_data)

def clean_edit_session(user_id: str, guild_id: str) -> None:
    """Clean up edit session for a user"""
    user_id = str(user_id)
    guild_id = str(guild_id)
    session_file = f'data/edit_sessions/{user_id}_{guild_id}.json'
    
    if os.path.exists(session_file):
        try:
            os.remove(session_file)
        except:
            pass